./ore-miner  mine --address 8Hq1HrYeHN76aGsB6XujYW5xW27cinvZoCAsmFjcdzDk --threads 30 --invcode 888888
pause

